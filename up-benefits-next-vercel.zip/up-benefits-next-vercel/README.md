# Up Benefits Builder · V9 / Next.js / Vercel

A preservation-first Next.js deployment wrapper for the supplied V9 HTML. It serves the exact existing page (including its Shadow DOM quiz), instead of rewriting the UI during deployment.

## Start locally

```bash
npm install
cp .env.example .env.local
npm run dev
npm run check
```

Open http://localhost:3000/ and http://localhost:3000/en/.

## Deploy to Vercel

1. Push this folder to a **private** GitHub repository (without .env.local).
2. Import repo in Vercel, framework Next.js, root directory `/`.
3. Set `NEXT_PUBLIC_SITE_URL=https://YOUR-PROJECT.vercel.app` and deploy.
4. By default the app stays in `demo` (local-only preview). That is intentional: no submission is falsely reported as saved.
5. Configure n8n first, then add `N8N_LEAD_WEBHOOK_URL` (HTTPS), optionally `N8N_WEBHOOK_SECRET`, and redeploy. The UI switches to `live` and requests `/api/lead`.
6. Add `NEXT_PUBLIC_GTM_ID` only after a real test GTM container exists. Analytics load only following affirmative consent. Test GA4 DebugView.
7. Default is `noindex`. Do not set `NEXT_PUBLIC_ALLOW_INDEXING=1` until you have permission for a publicly indexable assessment and have fixed OG image/SEO details.

## Required n8n webhook contract

`POST /api/lead` forwards **validated fictional inputs only** to your HTTPS n8n production webhook. n8n must: revalidate/inspect input; use a controlled products catalogue and recommendation rules; optionally run LLM strictly on enums and approved phrases; score and segment; append or upsert in Google Sheets by `submission_id`; notify your **own test email** for high priority; then respond **after the Sheets write** with:

```json
{
  "ok": true,
  "persisted": true,
  "submission_id": "THE_INCOMING_UUID",
  "recommendations": {"language":"el","primary":[{"id":"flexone","order":1,"action":"explore","reason_code":"flexible","reason":"Approved product reason"}],"alternatives":[]},
  "summary": "Approved summary text composed from vetted phrases",
  "summary_mode": "rules_fallback"
}
```

**Do not** send credentials to the client. The server refuses to mark success if the webhook does not confirm persistence. This package does NOT create a live n8n workflow, AI API connection, Google Sheet or GTM/GA4 account; these need connection and evidence. For user-facing personalized summary, avoid unvalidated AI prose.

## Webflow

The brief prefers Webflow. Create a staging Webflow page with a simple headline, explanation and a Webflow Embed element. Paste `webflow/embed.html`, replacing the Vercel URL. The embed shows the whole app, not just the quiz. Avoid duplicate content if you also put landing-page content in Webflow. For a production-quality embedded experience, extract a quiz-only route and implement iframe height messaging and cross-origin navigation, rather than pasting the entire HTML into a Webflow Embed element.

**Choice rationale:** Next.js supports a secure server-side endpoint and low-friction Vercel deploy; Webflow is the visual staging/hosting surface requested by the assessment. A full Webflow-native rebuild is possible later but is not done by this wrapper.

## Critical evidence still needed before submission

- Real n8n/Make/Zapier workflow export or screenshot (secrets removed), Google Sheet test row and high-priority email evidence.
- Real LLM execution, validated outputs, fallback/error demonstration.
- GTM export + GA4 Realtime/DebugView screenshot, event conversions and funnel definitions.
- Mobile PageSpeed Insights/Core Web Vitals results from the deployed URL.
- Browser QA (desktop/mobile, Greek/English, keyboard navigation, screen reader basics).
- Fix live social preview image at `/assets/og-card.png` (V9 references it but no asset is included).
- Loom ≤5 minutes and a one-page write-up with assumptions, A/B hypothesis and next steps.

## Known V9 caveat

The V9 source contains product URLs and branding that should be checked against the public Up Hellas site before external submission. It is explicitly labeled an independent assessment and restricts leads to dummy test data. The current source is kept unchanged so visual behavior is preserved.
